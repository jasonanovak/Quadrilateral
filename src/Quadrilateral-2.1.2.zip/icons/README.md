The icons are generated using https://favicon.io/favicon-generator/.

The font is blaka, size 140, the background color is #888.